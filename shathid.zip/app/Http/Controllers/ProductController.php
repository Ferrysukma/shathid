<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function index($id)
    {
        // Get Detail Product
        $product      = DB::table('product')->where('product_id', $id)->first();

        return view('product.detail', [
            'product'   => $product
        ]);
    }
}
